# BenPet v0.1

BenPet is a lightweight desktop pet prototype built with Tauri 2, Rust, Vite, and JavaScript.

## Current Phase 1 features

- Transparent, frameless desktop window
- GIF character slot with CSS fallback placeholder
- Drag the pet with the left mouse button
- Right-click context menu
- Three display modes: free, edge, and walk
- Character scale controls (50%–200%)
- Always-on-top toggle
- Save basic settings and last window position in WebView local storage

## Requirements

- Node.js LTS and npm
- Rust toolchain
- Tauri 2 system prerequisites for your operating system

Official setup guides:
- https://v2.tauri.app/start/prerequisites/
- https://v2.tauri.app/start/create-project/

## Run in development

```bash
npm install
npm run tauri dev
```

## Build installers

```bash
npm run tauri build
```

Installer outputs are placed under `src-tauri/target/release/bundle/`.

## Character assets

Put transparent GIF files in `assets/character/`. See `assets/character/README.md`.

## Notes

- The browser preview (`npm run dev`) is not equivalent to the native desktop app. Native window features such as dragging, always-on-top, positioning, and monitor detection require Tauri.
- The current prototype is a foundation, not a finished production release.
- The edge and walk modes are initial implementations and need testing on each desktop environment.
- Linux support depends on the installed WebKitGTK and desktop compositor. Transparent always-on-top windows can behave differently across GNOME, KDE, Wayland, and X11.
- No microphone, screen capture, browser monitoring, or AI access is enabled in this version.
- Settings currently use WebView local storage. A later phase can move persistent settings to a native storage layer.
